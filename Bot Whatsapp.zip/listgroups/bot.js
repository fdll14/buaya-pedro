const test = "halo tuan bot anda masih online";
const botPricelist = `*Pricelist Lengkap Buaya Store* :

Pricelist Kebutuhan Sosmed
https://bit.ly/RessSosmedBuStore

Pricelist Kebutuhan Cheat Game
https://bit.ly/RessCheatBuStore

Pricelist Topup Game dan App Premium 
https://bit.ly/RessTopupBuStore`
const sewa = "Halo untuk menyewa bot ini kalian bisa chat ke pemilik saya wa.me/62895422836123"
const botMenu = `*Menu* :

*!payment* untuk melihat daftar pembayaran
*!pricelist* untuk melihat daftar layanan

*!ml* untuk melihat pricelist dm mobile legends
*!valo* untuk melihat pricelist valorant point
*!epep* untuk melihat pricelist dm free fire


*!sewa* untuk melihat kontak pemilik saya`
const botPayment = `*Payment Buaya Store* :

*Kebutuhan Social Media & Cheat Game*
BCA 3600301429 (Muhamad Shuro Fadhiah)
Gopay 0895422836123 (Muhamad Shuro Fadhiah)
Dana 0895422836123 (Muhamad Shuro Fadhiah)
ShopeePay 0895422836123 (Muhamad Shuro Fadhiah)
      
*Kebutuhan Topup dan App Prem*
BCA 0241071170 (Wirajaya Trie Pamungkas)
Gopay 085230998686 (Wirajaya Trie Pamungkas)
Dana 085230998686 (End Rah)
ShopeePay 085230998686 (@wirzyy11)`
const botML = `*Pricelist DM Mobile Legends By Buaya Store* :

14💎(13+1) Rp3.800,00
56💎(51+5) Rp14.500,00
86💎(78+8) Rp19.700,00
114💎(104+10) Rp26.900,00
172💎(156+16) Rp38.500,00
257💎(234+23) Rp58.500,00
285💎(260+25) Rp65.500,00
344💎(312+32) Rp77.000,00
429💎(390+39) Rp96.000,00
514💎(468+46) Rp114.900,00
556💎(506+50) Rp125.400,00
600💎(546+54) Rp134.500,00
720💎(638+82) Rp156.600,00
878💎(781+97) Rp192.500,00
963💎(859+104) Rp210.800,00
1.454💎(1289+165) Rp314.300,00
2.195💎(1860+335) Rp456.000,00
2.901💎(2485+416) Rp606.500,00
3.688💎(3099+589) Rp758.700,00
4.394💎(3724+670) Rp910.500,00
5.532💎(4649+883) Rp1.148.000,00

Noted :
Order dengan memberikan ID+Server`
const botEPEP = `*Pricelist DM Free Fire By Buaya Store* :

20💎Rp3.100,00
50💎Rp7.300,00
70💎Rp9.800,00
100💎Rp14.200,00
140💎Rp19.500,00
210💎Rp29.200,00
355💎Rp48.500,00
720💎Rp96.500,00
1.440💎Rp193.000,00
2.000💎Rp263.500,00
Membership Mingguan Rp29.000,00
Membership Bulanan Rp85.000,00


*Noted :*
Order dengan memberikan ID`
const botValo = `*Pricelist Valorant Point By Buaya Store* :

300 VP Rp34.500,00
625 VP Rp64.500,00
1125 VP Rp111.500,00
1250 VP Rp125.000,00
1650 VP Rp157.500,00
2275 VP Rp219.500,00
2775 VP Rp265.500,00
3400 VP Rp312.000,00
4525 VP Rp420.000,00
5050 VP Rp467.500,00
7000 VP Rp622.500,00
8650 VP Rp777.500,00


*Noted :*
Order dengan memberikan Riot ID`

  module.exports = {
    sewa,
    test,
    botPricelist,
    botMenu,
    botPayment,
    botML,
    botEPEP,
    botValo
  }