const ads = `*Garapan Akun Ads Google*

Buat yang akun yang pertama kali lolos saat dipake buyer gw bakal dibayar 50k ingat untuk akun pertama yg lolos.

Syarat:
- Akun gmail minimal berumur 7 hari an (jangan yang baru bikin trus langsung buat garap).
- Punya laptop ( lewat hp boleh asal menggunakan mode pakar )
- Akun gmail kosongan (tidak terdapat nomor hp atau google pemulihan).
- Pastikan verifikasi 2 langkah mati.
- Pastikan akun ads sudah di acc selama seminggu sebelum kalian setorkan.
- Baca dulu penjelasan dibawah sebelum garap.

Tutorial :
https://drive.google.com/drive/u/0/folders/1F_T3s0yY7e9wZAMUFk5MgVQxd1WpsLhh

System pembayaran :

Kalian setorin emailnya dengan sesuai syarat diatas, buyer gw coba dan liat hasilnya kalo akunnya *bisa dapat trafik stabil* bakal dibayar.

QnA :

1. *Kapan pembayarannya* ? Pembayaran nunggu konfirmasi dulu dari buyer gw. 

2. *Bakal dibayar berapa* ? kalian bakal dibayar 25k per akun dengan catatan akun kalian bisa jalan dapat trafik yang stabil dengan pemakaian anggaran diatas 500k.

3. *Berapa lama kira kira biar dibayar* ? Secepatnya pokoknya tergantung buyer gw ini karna dia perlu coba akunnya satu per satu jadi butuh waktu. Dan nunggu trafiknya ngabisin anggaran diatas 500k.

3. *Kenapa ko jadi ribet gini bang* ? Ya mau gimana lagi kebanyakan akunnya dicoba malah ditangguhkan semua kata buyer gw kalo ga ya ga muncul trafik stabil.

4. *Kalo garap tapi akunnya pas dipake ditangguhkan atau suspend gimana* ? solusinya kalian mesti ngelakuin banding untuk akun tersebut kalo lolos banding bisa disetorin lagi. Kalo setelah banding tetap ditangguhkan/suspend gimana ? akun kalian akan tetap gw bayar pake uang gw pribadi tapi hanya bakal dibayar 5k.

5. *Ko rewardnya berkurang dan syaratnya jadi ribet gini* ? ya mau gimana lagi google update algoritma.

Note
*Kalo ada pertanyaan tanyakan di group jangan ngepm`


const gestun = `*Gestun spaylater*

instan fee 5% via scan,chat langsung ke wa.me/6285888547810
#promotion`

const garapan = `*List Garapan Buaya Cuan* :

*!adsgoogle*
`
const cv = `*Buaya Store Jasa Convert*

* Convert Saldo (Dana,Gopay,Ovo,jago,Neo,Linkaja,Spay)
* Convert Antar Bank
* Convert Dolar Paypal - Rate 12k/1$
* Convert Pulsa ( Three Only) - Rate 0.80

Fee CV Saldo :
10k - 99k fee 1k
100k - 199k fee 2k
200k - 499k fee 5k
500 - 1000k fee 10k

Dibawah 10k gratis untuk member *buaya cuan*
`

const adsMenu = `*Menu* :

*!garapan* untuk melihat list garapan yang ada
*!cv* untuk melihat list convert yang tersedia
*!gestun* untuk melihat list gestun yan tersedia
*!sewa* untuk melihat kontak pemilik saya`


  module.exports = {
    ads,
    adsMenu,
    garapan,
    cv,
    gestun

  }