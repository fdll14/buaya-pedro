const three = `*Daftar Paket Kuota Three*

1. AON Tri Baru
- Mini AON 1GB All Jaringan 5 Hari - 10.428
- Mini AON 1,5GB All Jaringan 7 Hari - 14.324
- 2,5GB All Jaringan 365 Hari - 16.200
- 12GB All Jaringan 365 Hari - 51.850
- 40GB All Jaringan 365 Hari - 95.650

2. Tri All Jaringan
- 10GB All Jaringan 30 Hari - 46.800
- 15GB All Jaringan 30 Hari - 56.800
- 20GB All Jaringan 30 Hari - 69.300
- 30GB All Jaringan 30 Hari - 96.800
- 50GB All Jaringan 30 Hari - 111.800

3. Tri Data Happy
- Mini Happy 1,5GB 1 Hari - 4.650
- Mini Happy 2,5GB 1 Hari - 6.650
- Mini Happy 3GB 3 Hari - 9.900
- Mini Happy 3,5GB 5 Hari - 13.950
- Mini Happy 3GB 30 Hari - 14.000
- Mini Happy 7GB 30 Hari - 28.175
- Mini Happy 11GB 30 Hari - 41.650
- Mini Happy 14GB 30 Hari - 53.900
- Mini Happy 18GB 30 Hari - 56.800
- Mini Happy 30GB 30 Hari - 66.500
- Mini Happy 42GB 30 Hari - 79.000
- Mini Happy 55GB 30 Hari - 106.900
- Mini Happy 100GB 30 Hari - 130.900

`

  module.exports = {
    three
  }