// bot kelar tgl 25/09/2022

const aPayment = `*PAYMENT*

372401000906502 (BRI).
Maulia Ahnas Hidayat

087899777340 , Dana/OVO/ SHOPEEPAY (Maulia Ahnas Hidayat) 

#QRIS ALLSCAN

ORDER = SABAR
karena kesalahan saya yang nanggung`
const aMenu = `*Menu* :

*!payment* untuk melihat daftar pembayaran

*!ml* untuk melihat pricelist mobile legends
*!lol* untuk melihat pricelist league of legends
*!epep* untuk melihat pricelist free fire
*!gi* untuk melihat pricelist genshin impact
*!apex* untuk melihat pricelist Apex Legend Mobile
*!roblox* untuk melihat pricelist Roblox

 *!sewa* untuk menyewa bot`

const aML = `*MOBILE LEGENDS*
*PAKET A*
RATE:
110    DIAMOND 23.000
275    DIAMOND 48.000
565    DIAMOND 85.000
1.155  DIAMOND 165.000
1.765  DIAMOND 245.000
2.975 DIAMOND 440.000
6.000 DIAMOND 730.000
[LANGSUNG KEKIRIM]


~~~~~~
*PAKET B*
2380 DIAMOND 290.000
4860 DIAMOND 550.000
9720 DIAMOND 1.050.000
12100 DIAMOND 1.300.000
31540 DIAMOND 3.190.000
60700 DIAMOND 6.000.000
[HARUS MAIN MINIMAL 3×]


•paket B di proses 1-3 jam
•100% legal dan dapat invoice`

const aGi = `*GENSHIN IMPACT*
RATE:
60 GENESIS CRYSTAL 12.500
300 GENESIS CRYSTAL 55.000
980 GENESIS CRYSTAL 155.000
1980 GENESIS CRYSTAL 318.000
3280 GENESIS CRYSTAL 528.000
6480 GENESIS CRYSTAL
1.055.000`
const apex = `*APEX LEGEND MOBILE*

RATE: 
90 SG = Rp 11.500
465+35 SG = Rp 41.500
935+115 SG = Rp 80.000
2340+410 SG = Rp 188.000
4680+970 SG = Rp 382.500
9365+2135 SG = Rp 735.000`

const aEPEP = `*FREE FIRE* 

100 DM (1$) = 13.000
310 DM (3$) = 38.000
520 DM (5$) = 63.000
1060 DM (10$) = 125.000
2180 DM (20$) = 247.000
5600 DM (50$) = 600.000
MEMBER MINGGUAN (2$) = 24.000
MEMBER BULANAN (6.5$) = 74.000

Login VK/FB/Google
Legal & Garansi 100%
Pay Google play ( Have receipt )`
const aLol = `*LEAGUE OF LEGENDS*
410 WILD CORE 38.000
1350 WILD CORE 90.000
2000 WILD CORE 147.000
3600 WILD CORE 220.000
7600 WILD CORE 445.000`

const roblox = `*LIST TOPUP ROBLOX*

80       ROBUX Rp 12.000
400     ROBUX Rp 55.000
800     ROBUX Rp 105.000
1700   ROBUX Rp 210.000
4500   ROBUX Rp 520.000
10000 ROBUX Rp 1.035.000
`
const aEvent = `*EVENT PROMO*,
*LEAGUE OF LEGENDS*
410 WILD CORE 38.000
1350 WILD CORE 85.000
2000 WILD CORE 145.000
3600 WILD CORE 215.000
7600 WILD CORE 420.000`

  module.exports = {
    aMenu,
    aPayment,
    aML,
    aGi,
    aEPEP,
    aLol,
    apex,
    roblox,
    aEvent
  }